import numpy as np
import cv2 as cv
import math
import skimage.morphology as mph
import matplotlib.pyplot as plt
from scipy import signal


def show(img):
    if img.ndim == 2:
        plt.imshow(img, cmap='gray')
    else:
        plt.imshow(cv.cvtColor(img, cv.COLOR_BGR2RGB))
    plt.show()


def Hessian(img, sigma):
    if sigma < 1:
        print('error: sigma<1')
    img = np.array(img, dtype=float)
    sigma = np.array(sigma, dtype=float)
    s_round = np.round(3 * sigma)
    [X, Y] = np.mgrid[-s_round:s_round + 1, -s_round:s_round + 1]
    # 高斯函数二阶偏导数
    DGaussxx = 1 / (2 * math.pi * pow(sigma, 4)) * (X ** 2 / pow(sigma, 2) - 1) * np.exp(-(X ** 2 + Y ** 2) / (2 * pow(sigma, 2)))
    DGaussxy = 1 / (2 * math.pi * pow(sigma, 6)) * (X * Y) * np.exp(-(X ** 2 + Y ** 2) / (2 * pow(sigma, 2)))
    DGaussyy = 1 / (2 * math.pi * pow(sigma, 4)) * (Y ** 2 / pow(sigma, 2) - 1) * np.exp(-(X ** 2 + Y ** 2) / (2 * pow(sigma, 2)))
    # 构成Hession矩阵的二阶偏导数
    Dxx = signal.convolve2d(img, DGaussxx, boundary='fill', mode='same',fillvalue=0)
    Dxy = signal.convolve2d(img, DGaussxy, boundary='fill', mode='same',fillvalue=0)
    Dyy = signal.convolve2d(img, DGaussyy, boundary='fill', mode='same',fillvalue=0)
    return Dxx, Dxy, Dyy  # float64


def Eigenvalues(Dxx, Dxy, Dyy):
    tmp = np.sqrt((Dxx - Dyy) ** 2 + 4 * Dxy ** 2)
    # 计算特征值
    mu1 = 0.5 * (Dxx + Dyy + tmp)
    mu2 = 0.5 * (Dxx + Dyy - tmp)
    check = abs(mu1) > abs(mu2)
    lambda1 = mu1.copy()
    lambda1[check == True] = mu2[check == True]
    lambda2 = mu2
    lambda2[check == True] = mu1[check == True]
    return lambda1, lambda2  # float64


def FrangiFilter(img):
    global img_frangi
    img = np.array(img, dtype=float)
    defaultoptions = {'FrangiScaleRange': (3, 10), 'FrangiScaleRatio': 2,'beta': 0.5, 'c': 15,
                      'ShowProgress': True, 'FrontBlack': True}
    options = defaultoptions
    sigmas = np.arange(options['FrangiScaleRange'][0],options['FrangiScaleRange'][1],options['FrangiScaleRatio'])
    sigmas.sort()  # 升序
    beta = options['beta']
    c = options['c']
    shape = (img.shape[0], img.shape[1], len(sigmas))
    ALLfiltered = np.zeros(shape)
    for i in range(len(sigmas)):
        if (options['ShowProgress']):
            print('Current Frangi Filter Sigma: ', sigmas[i])
        Dxx, Dxy, Dyy = Hessian(img, sigmas[i])
        # 修正
        Dxx = pow(sigmas[i], 1.0) * Dxx
        Dxy = pow(sigmas[i], 1.0) * Dxy
        Dyy = pow(sigmas[i], 1.0) * Dyy
        lambda1, lambda2 = Eigenvalues(Dxx, Dxy, Dyy)
        lambda2[lambda2 == 0] = np.spacing(1)
        Rb = np.abs(lambda1) / np.abs(lambda2)
        S = np.sqrt(lambda1 ** 2 + lambda2 ** 2)
        # 计算响应值
        frangi = np.exp(-1 * Rb ** 2 / (2 * beta ** 2)) * (
                    1 - np.exp(-1 * S ** 2 / (2 * c ** 2)))
        if (options['FrontBlack']):
            frangi[lambda2 < 0] = 0
        else:
            frangi[lambda2 > 0] = 0
        # 保存结果
        ALLfiltered[:, :, i] = frangi
        if len(sigmas) > 1:
            frangi_out = ALLfiltered.max(2)

        else:
            frangi_out = ALLfiltered.reshape(img.shape)
        frangi_out = cv.normalize(frangi_out, None, 0, 255, cv.NORM_MINMAX)
        img_frangi = cv.convertScaleAbs(frangi_out)
    return img_frangi


def delete_intersection(img):  # 输入骨架图，前景白色；背景黑色
    src = img.copy()
    src = cv.copyMakeBorder(src, 10, 10, 10, 10, cv.BORDER_CONSTANT, value=0)
    h, w = src.shape
    # print(h,w)
    global interpoint
    endpoint = []
    interpoint = []
    for j in range(1, h - 1):
        for i in range(1, w - 1):
            itm = 0
            cont = 0
            for a in range(-1, 2):
                for b in range(-1, 2):
                    if src[j, i] == 255:
                        itm = itm + 1
                        if (src[j + a, i + b] == 255) & (itm != 5):
                            cont = cont + 1
            if cont == 1:
                endpoint.append((j, i))
            if cont > 2:
                interpoint.append((j, i))
    print('endpoints:', endpoint)
    print('interpoints:', interpoint)
    for k in interpoint:
        src[k] = 0
    return src


def zhixian_juli(p1,p2):
    return np.sqrt((p1[0]-p2[0])**2+(p1[1]-p2[1])**2)

def find_endpoints(src):
    """
    src为白色前景骨架图
    """
    h, w = src.shape
    endpoints = []
    for j in range(1, h - 1):
        for i in range(1, w - 1):
            itm = 0
            cont = 0
            for a in range(-1, 2):
                for b in range(-1, 2):
                    if src[j, i] == 255:
                        itm = itm + 1
                        if (src[j + a, i + b] == 255) & (itm != 5):
                            cont = cont + 1
            if cont == 1:
                endpoints.append((j, i))

            if cont == 0:
                src[j, i] = 0
    return endpoints


def find_another_endpoint(src, current_endpoint, endpoints):
    """
        src：白色前景骨架图
        current_endpoint：当前端点坐标
        endpoints：所有端点列表  需要注意的是，endpoints没有被修改
        所以即使有分段线已经连接了，也不会更新已经连接后的分段线端点，
        这样的好处是可以保证曲率较大的分段线也能连接在一起
    """
    (i, j) = current_endpoint
    newi, newj = i, j

    flag = 1
    while flag:
        pre = (i, j)
        i, j = newi, newj

        itm = 0
        for a in range(-1, 2):
            for b in range(-1, 2):
                itm = itm + 1
                if (src[i + a, j + b] == 255) & (itm != 5) & ((i + a, j + b) != pre):
                    (newi, newj) = (i + a, j + b)  # 更新坐标
                    # print(newi,newj)

        for k in endpoints:
            if k == (newi, newj):
                another_endpoint = k
                flag = 0
    return another_endpoint


def find_neighbourhood(a_single_point, size):
    """
    寻找指定点的邻域（距离准则）
       """
    i, j = a_single_point
    neighbourhood = []
    itm = 0
    for a in range(int(-(size - 1) / 2), int((size - 1) / 2 + 1)):
        for b in range(int(-(size - 1) / 2), int((size - 1) / 2 + 1)):
            itm += 1
            if itm != int((size - 1) / 2 * size + (size + 1) / 2):
                neighbourhood.append((i + a, j + b))
    return neighbourhood


def trans_angle(theta):
    """
    弧度转角度
    """
    angle = 180 * theta / math.pi
    return angle


def cal_angle(point1, point2):
    """
    计算某分段线与水平方向的夹角（角度准则）：
        point1,point2:分段线上的两个端点
    """
    # 图像坐标系（x下，y右）
    x = point2[0] - point1[0]
    y = point2[1] - point1[1]

    # 正常坐标系（x右，y上）
    xx = y
    yy = -x
    theta = math.atan2(yy, xx)

    # # 控制角度范围在(-pi/2,pi/2)内
    if theta <= -np.pi / 2:
        theta += np.pi
    if theta > np.pi / 2:
        theta -= np.pi

    # 弧度转角度
    angle = trans_angle(theta)
    return theta, angle


def cal_diff_distance(point1, point2):
    """
    计算两点欧式距离
    """
    distance = np.sqrt((point2[1] - point1[1]) ** 2 + ((point2[0] - point1[0]) ** 2))
    return distance


def cal_diff_angle(angle1, angle2):
    """
    计算两分段线之间的夹角
    """
    return abs(angle2 - angle1)


def connect_pos_improved(src, pos1, pos2):
    cv.line(src, (pos1[1], pos1[0]), (pos2[1], pos2[0]), (255, 255, 255), 1)
    pass


def fun_S(th1, th2, diff_distance, sum_angle):
    """
    1.距离准则
    2.角度准则
    若同时满足1和2，定义一个函数，当函数取最大值对应的点相连。
    """
    S = 10000 * th1 / (diff_distance + 1e-2) + th2 / (sum_angle + 1e-2)
    # 说明：这里距离项前面乘以系数1e4主要是为了增加距离项的权重
    return S


def main(src, th1, th2, th3, size):
    """
    主函数：
    th1:预连接两个点的长度阈值
    th2:角度阈值一般设定在30之内
    th3:角度阈值，通常设定一个较小的值25
    size:邻域尺寸,其值默认与th1相同！
    """
    h,w = src.shape
    for i in range(h):
        for j in range(w):
            if i == 0:
                src[i, j] = 0
            if i == h-1:
                src[i, j] = 0
            if j == 0:
                src[i, j] = 0
            if j == w-1:
                src[i, j] = 0

    global endpoints
    endpoints = find_endpoints(src)
    endpoints_copy = endpoints[:]
    global dic
    dic = {}
    flag = 1
    while flag:
        cur_endpoint = endpoints_copy.pop()
        neighbourhood = find_neighbourhood(cur_endpoint, size)
        p = 0
        for i in endpoints_copy:
            if i in neighbourhood:
                if cur_endpoint == find_another_endpoint(src, i, endpoints):
                    continue
                if cal_diff_distance(cur_endpoint, i) > cal_diff_distance(
                        find_another_endpoint(src, cur_endpoint, endpoints), i):
                    continue
                if cal_diff_distance(cur_endpoint, i) > cal_diff_distance(find_another_endpoint(src, i, endpoints),
                                                                          cur_endpoint):
                    continue

                diff_distance = cal_diff_distance(cur_endpoint, i)

                theta1, angle1 = cal_angle(cur_endpoint, find_another_endpoint(src, cur_endpoint, endpoints))

                theta2, angle2 = cal_angle(i, find_another_endpoint(src, i, endpoints))

                theta3, angle3 = cal_angle(cur_endpoint, i)

                # 计算两个锐角
                beta1 = np.abs(angle1 - angle3)
                if beta1 > 90:
                    beta1 = 180 - beta1

                beta2 = np.abs(angle2 - angle3)
                if beta2 > 90:
                    beta2 = 180 - beta2

                # 计算当前分段线与i分段线最远的两个点的连线与水平方向的夹角
                theta4, angle4 = cal_angle(find_another_endpoint(src, cur_endpoint, endpoints),
                                           find_another_endpoint(src, i, endpoints))

                # 计算另外两个锐角
                alpha1 = np.abs(np.abs(angle1) - np.abs(angle4))
                if alpha1 > 90:
                    alpha1 = 180 - alpha1

                alpha2 = np.abs(np.abs(angle2) - np.abs(angle4))
                if alpha2 > 90:
                    alpha2 = 180 - alpha2

                if (alpha1 >= th3) | (alpha2 >= th3):
                    continue

                # 最终条件判断
                if (diff_distance <= th1) & (beta1 <= th2) & (beta2 <= th2):
                    # 打印变量是因为通过观察连接效果动态地调整阈值参数
                    S = fun_S(th1, th2, diff_distance, beta1 + beta2)
                    dic[(cur_endpoint, i)] = S

                    #                     print(f'\tdiff_distance:{diff_distance}\n\tbeta1:{beta1}\n\tbeta2:{beta2}\n\talpha1:{alpha1}\n\talpha2:{alpha2}')
                    p = 1

        if len(endpoints_copy) == 0:
            flag = 0

    print('\n字典内容：\n', dic, '\n')
    if len(dic) != 0:
        print(
            '----------------------------------------------开始操作字典，执行连接函数-----------------------------------------------------')
        mark = 1
        while mark:
            candidate = list(dic.keys())[list(dic.values()).index(max(dic.values()))]
            print('连接函数执行，连接的两个点是：', candidate[0], candidate[1])
            connect_pos_improved(src, candidate[0], candidate[1])
            # show(src) ##

            for k in list(dic.keys()):
                if (k[0] == candidate[0]) | (k[0] == candidate[1]) | (k[1] == candidate[0]) | (k[1] == candidate[1]):
                    del dic[k]
            #             print(dic)

            if len(dic) == 0:
                mark = 0

    print('----------------------------------------连接完毕---------------------------------------------')
    return src