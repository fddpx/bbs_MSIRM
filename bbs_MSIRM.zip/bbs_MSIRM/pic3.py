import cv2 as cv
import numpy as np
import skimage.morphology as mph
import matplotlib.pyplot as plt
import fuctions


img = cv.imread('pic/pic3.png')
print(img.shape)
gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
cv.imshow('gray', gray)
cv.waitKey(2000)
cv.destroyAllWindows()

img_bf = cv.bilateralFilter(gray, -1, sigmaColor=50,sigmaSpace=3)
# 注：pic1与pic4 sigmaSpace取9 ； 由于pic2与pic3岩块纹理较细，sigmaSpace取3即可！!
cv.imshow('img_bf', img_bf)
cv.waitKey(2000)
cv.destroyAllWindows()


frangi = fuctions.FrangiFilter(img_bf)
frangi = 255 - frangi  # 转换为前景为黑色背景为白色
cv.imshow('frangi', frangi)
cv.waitKey(2000)
cv.destroyAllWindows()


clahe = cv.createCLAHE(clipLimit=5.0)
o = clahe.apply(frangi)
cv.imshow('o', o)
cv.waitKey(2000)
cv.destroyAllWindows()


_, binary = cv.threshold(o, 0, 255, cv.THRESH_OTSU)
# print(_)
cv.imshow('binary', binary)  # binary前景为黑色
cv.waitKey(2000)
cv.destroyAllWindows()

binary = 255 - binary
contours, hierarchy = cv.findContours(binary, cv.RETR_LIST,cv.CHAIN_APPROX_SIMPLE)

I = []
for i in range(len(contours)):
    if cv.contourArea(contours[i]) > 50:  # 面积 设定50左右
        I.append(i)
print(I)
a = np.zeros_like(binary, dtype=np.uint8)
contoursImg = cv.merge([a, a, a])
[cv.drawContours(contoursImg, contours, m, (255, 255, 255), 0) for m in I]
cont = cv.cvtColor(contoursImg, cv.COLOR_BGR2GRAY)


contours1, hierarchy1 = cv.findContours(cont, cv.RETR_LIST,cv.CHAIN_APPROX_SIMPLE)
II = []
for i in range(len(contours1)):
    min_rect = cv.boxPoints(cv.minAreaRect(contours1[i])).astype(np.int32)
    min_rect_sorted = min_rect[np.argsort(min_rect[:, 0])]
    diyi=min_rect_sorted[0]
    dier=min_rect_sorted[1]
    disan=min_rect_sorted[2]
    duan = fuctions.zhixian_juli(diyi,dier)
    chang = fuctions.zhixian_juli(dier,disan)
    if chang/duan >= 1 :       # 长短轴比 默认值为1，可根据实际需要修改
        II.append(i)
print('II:',II)

aa = np.zeros_like(binary, dtype=np.uint8)
contoursImg1 = cv.merge([aa, aa, aa])
[cv.drawContours(contoursImg1, contours1, m, (255, 255, 255), -1) for m in II]
cont1 = cv.cvtColor(contoursImg1, cv.COLOR_BGR2GRAY)
cv.imshow('cont', cont1)
cv.waitKey(2000)
cv.destroyAllWindows()


cont1[cont1 == 255] = 1
skeleton0 = mph.skeletonize(cont1)
skeleton = skeleton0.astype(np.uint8) * 255
length = []
for i in range(500):
    for j in range(500):
        if skeleton[i, j] == 255:
            length.append((i, j))

skeleton = 255 - skeleton
cv.imshow('skeleton', skeleton)
cv.waitKey(2000)
cv.destroyAllWindows()

skeleton = 255 - skeleton
src = fuctions.delete_intersection(skeleton)  # 白色前景


h, w = src.shape
endpoint2 = []  # 列表中储存的是去除交叉点后图像的所有端点
for j in range(1, h - 1):
    for i in range(1, w - 1):
        itm = 0
        cont = 0
        for a in range(-1, 2):
            for b in range(-1, 2):
                if src[j, i] == 255:
                    itm = itm + 1
                    if (src[j + a, i + b] == 255) & (itm != 5):
                        cont = cont + 1
        if cont == 1:
            endpoint2.append((j, i))

        if cont == 0:
            src[j, i] = 0
print('endpoint2:', endpoint2)


lists = [[] for m in range(len(endpoint2))]
print(lists)
remove = []  # 用于储存边界线另外一个端点
for ii in range(len(endpoint2)):
    (j, i) = endpoint2[ii]
    flag = 1
    for k in remove:
        if endpoint2[ii] == k:
            flag = 0
            break
    if flag == 0:
        continue
    else:
        lists[ii].append((j, i))  # 将起点放进列表中

    newj = j
    newi = i
    a = 1
    while a:
        pre = (j, i)
        j = newj
        i = newi
        itm = 0
        for a in range(-1, 2):
            for b in range(-1, 2):
                if src[j, i] == 255:
                    itm = itm + 1
                    if (src[j + a, i + b] == 255) & (itm != 5) & (
                            (j + a, i + b) != pre):
                        (newj, newi) = (j + a, i + b)  # 更新坐标
                        lists[ii].append(
                            (newj, newi))  # 将起点之后的各个点放进列表（包括另外一个端点）
        for jj in endpoint2:
            if (newj, newi) == jj:
                remove.append(jj)
                print('remove:', remove)
                a = 0
print('number of endpoints:', len(lists))

for i in lists:
    # print('长度，元素：', len(i), i)
    if len(i) < 32:  # 长度阈值，根据需要出去毛刺的长短合理确定
        for m in i:
            src[m[0], m[1]] = 0
src = 255 - src  # 转换为黑色前景并保存
src = src[10:510, 10:510]
cv.imshow('src', src)
cv.waitKey(2000)
cv.destroyAllWindows()


# 连接
result = fuctions.main(255-src,81, 30, 25, 81)
cv.imwrite('pic/pic3_result.png',255-result)

cv.imshow('result',255-result)
cv.waitKey(0)
cv.destroyAllWindows()

